

import * as funciones from "./funciones.js";

function toggleNav(){
  navbar.classList.toggle('active');
}
const burgerMenu = document.querySelector('.icono-menu-lateral');
const navbar = document.querySelector('.opciones-header'); 
const closeButton = document.querySelector('.closeButton');
// Event Listeners para abrir y cerrar el navbar al hacer clic en el icono del menú o en el botón de cierre.
burgerMenu.addEventListener('click',toggleNav);
closeButton.addEventListener('click',toggleNav)

// Event Listener para el enlace de logout

const logoutLink = document.querySelector(".logout-link");


  logoutLink.addEventListener("click", function (event) {
    event.preventDefault();
    localStorage.removeItem("user"); //eleimnar el usario del localstorage
    localStorage.removeItem("token");//eliminar el tocken lstrg
    navigate();// Función para redirigir al usuario a la página de inicio de sesión
  });
  

// Event Listener para ejecutar funciones después de cargar el contenido

document.addEventListener("DOMContentLoaded", function () {
  const carrito = document.getElementById("carrito");
  const listaproductos = document.getElementById("lista-productos");
  const listaCarrito = document.querySelector("#lista-carrito tbody");
  const vaciarCarritoBtn = document.querySelector("#vaciar-carrito");
  var productosEnCarrito = obtenerProductosLocalStorage() || [];
  obtenerCarritoYImprimirPagina();

  function obtenerCarritoYImprimirPagina() {
    imprimirdatosjson();
    listarCarrito();
  }
  // Event Listener para agregar productos al carrito

  listaproductos.addEventListener("click", function agregar(e) {
    if (e.target.classList.contains("agregar-carrito")) {
      const producto = e.target.parentElement.parentElement;
      const detallesProducto = obtenerInfoProducto(producto);
      insertarProducto(detallesProducto);
      listarCarrito();
      guardarProductosEnLocalStorage();
    }
  });
  // Función para obtener la información del producto

  function obtenerInfoProducto(producto) {
    return {
      imagen: producto.querySelector("img").src,
      titulo: producto.querySelector("h3").textContent,
      precio: producto.querySelector(".precio span").textContent,
      id: producto.querySelector("a").dataset.id,
    };
  }
  // Función para insertar un producto en el carrito
  function insertarProducto(producto) {
    const productoExist = productosEnCarrito.find((item) => item.id === producto.id);
    if (productoExist) {
      productoExist.cantidad++;
    } else {
      producto.cantidad = 1;
      productosEnCarrito.push(producto);
    }
  }
  // Función para listar los productos en el carrito

  function listarCarrito() {
    borradoEficienteArbol(listaCarrito);
    productosEnCarrito.forEach((producto) => {
      const fila = document.createElement("tr");
      fila.innerHTML = `
                     <td><img src="${producto.imagen}" width="60px" height"60px"></td>
                      <td>${producto.titulo}</td>
                      <td>${producto.precio}</td>
                      <td class="cantidad">${producto.cantidad}</td>
                      <td><a href="#" class="borrar-producto" data-id="${producto.id}">X</a></td>
                    `;
      listaCarrito.appendChild(fila);
      guardarProductosEnLocalStorage();
    });
  }

  vaciarCarritoBtn.addEventListener("click", function vaciarCarrito() {
    borradoEficienteArbol(listaCarrito);
    productosEnCarrito = [];
    guardarProductosEnLocalStorage();
  });

  carrito.addEventListener("click", function eliminarProducto(e) {
    if (e.target.classList.contains("borrar-producto")) {
      e.target.parentElement.parentElement.remove();
      const productoId = e.target.dataset.id;
      productosEnCarrito = productosEnCarrito.filter((producto) => producto.id !== productoId);
      guardarProductosEnLocalStorage();
    }
  });
  // Función para guardar los productos en el localStorage

  function guardarProductosEnLocalStorage() {
    localStorage.setItem("productos", JSON.stringify(productosEnCarrito));
  }

  function obtenerProductosLocalStorage() {
    return JSON.parse(localStorage.getItem("productos")) || [];
  }
});


// Función para eliminar de manera eficiente todos los hijos de un nodo

function borradoEficienteArbol(nodoArbol) {
  while (nodoArbol.firstChild) {
    borradoEficienteArbol(nodoArbol.firstChild);
    nodoArbol.removeChild(nodoArbol.firstChild);
  }
}

function navigate() {
  window.location.href = "http://127.0.0.1:5500/login/loginyregistro.html";
}

const buyButton = document.getElementById("procesar-pedido").addEventListener("click", function () {
  if (localStorage.getItem('user') == null) {
    alert("Debes iniciar sesión para poder comprar");
    navigate();
  }
});

// Función asincrónica para obtener y mostrar datos desde una API de productos

async function imprimirdatosjson() {
  try {
    const response = await fetch("http://localhost/api/productos");
    if (!response.ok) {
      throw new Error(`¡Error HTTP! Estado: ${response.status}`);
    }
    const datosjson = await response.json();

    const listadoproductos = document.getElementById("lista-productos");
    let rowDiv = document.createElement("div");
    rowDiv.classList.add("row");

    datosjson.forEach((producto, filas) => {
      var productoDiv = document.createElement("div");
      productoDiv.classList.add("four", "columns", "card");
      productoDiv.innerHTML = `
        <img src="http://localhost:/images/${producto.imagen}" class="imagen-producto" />
        <div class="info-card">
          <h3>${producto.nombre}</h3>
          <p class="texto">${producto.descripcion}</p>
          <p class="precio"><span>${producto.precio}€ <small>/Mes</small></span></p>
          <a href="#" class="button-primary button input agregar-carrito" data-id="${producto.id}">Contratar</a>
        </div>
      `;

      rowDiv.appendChild(productoDiv);

      // If we've reached the third product, add the row to the main container and reset it
      if ((filas + 1) % 3 === 0 || filas === datosjson.length - 1) {
        listadoproductos.appendChild(rowDiv);
        rowDiv = document.createElement("div");
        rowDiv.classList.add("row");
      }
    });
  } catch (error) {
    console.error("Error al obtener productos:", error);
  }
}



  
