export { borradoEficienteArbol, imprimirdatosjson };

function borradoEficienteArbol(nodoArbol) {
  while (nodoArbol.firstChild) {
    borradoEficienteArbol(nodoArbol.firstChild);
    nodoArbol.removeChild(nodoArbol.firstChild);
  }
}

function navigate() {
  window.location.href = "http://127.0.0.1:5500/login/loginyregistro.html";
}

// Event Listener para el botón de procesar pedido

const buyButton = document
  .getElementById("procesar-pedido")
  .addEventListener("click", function () {
        // Verificar si el usuario está logueado antes de proceder con la compra

    if (localStorage.getItem("user") == null) {
      alert("Debes iniciar sesion para poder comprar");
      navigate();// Redirigir al usuario a la página de inicio de sesión
    } else localStorage.getItem("user") != null;
          // Si el usuario está logueado, proceder a insertar el pedido

    insertarPedido();
  });
// Obtener el usuario y los productos del localStorage

let user = localStorage.getItem("user");
user = JSON.parse(user);
let products = localStorage.getItem("productos");
products = JSON.parse(products);

// Función asincrónica para insertar el pedido en la API
const insertarPedido = async () => {
  // Obtener los IDs de los productos del carrito
let product_ids = products.map((product) => product.id);
  // Obtener el ID del usuario

  let user_id = user.id;

  try {
    const response = await fetch("http://localhost/api/compras", {
          // Enviar la solicitud POST a la API para insertar el pedido

      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        user_id: user_id,
        producto_ids: product_ids,
      }),
    });
    if (!response.ok) {
      throw new Error(`HTTP error! Status: ${response.status}`);
    }
        // Si la inserción es exitosa, mostrar mensaje de éxito, limpiar el carrito y mostrar un mensaje al usuario

    const data = await response.json();
    console.log(data);
    localStorage.removeItem("productos"); // Limpiar el carrito en localStorage
    swal("EN AHORA BUENA!", "Pedido realizado con éxito !", "success");
  } catch (error) {
    console.log(user_id);
    console.log(product_ids);
    console.error("Error:", error);
  }
};




async function imprimirdatosjson() {
  try {
    const response = await fetch("http://localhost/api/productos");
    if (!response.ok) {
      throw new Error(`¡Error HTTP! Estado: ${response.status}`);
    }
    const datosjson = await response.json();

    const listadocursos = document.getElementById("lista-cursos");
    let rowDiv = document.createElement("div");
    rowDiv.classList.add("row");

    datosjson.forEach((producto, filas) => {
      var productoDiv = document.createElement("div");
      productoDiv.classList.add("four", "columns", "card");
      productoDiv.innerHTML = `
        <img src="http://localhost:/images/${producto.imagen}" class="imagen-curso u-full-width"  />
        <div class="info-card"> 
          <h4>${producto.nombre}</h4>
          <p>${producto.descripcion}</p>
          <p class="precio"><span class="u-pull-right">€${producto.precio}</span></p>
          <a href="#" class="u-full-width button-primary button input agregar-carrito" data-id="${producto.id}">Agregar Al Carrito</a>
        </div>
      `;

      rowDiv.appendChild(productoDiv);

      // Si hemos llegado al tercer curso, agregar la fila al contenedor principal y reiniciarla
      if ((filas + 1) % 3 === 0 || filas === datosjson.length - 1) {
        listadocursos.appendChild(rowDiv);
        rowDiv = document.createElement("div");
        rowDiv.classList.add("row");
      }
    });
  } catch (error) {
    console.error("Error al obtener productos:", error);
  }
}
