
document.addEventListener('DOMContentLoaded', function() {
  // Función para alternar la clase 'active' en el navbar
  function toggleNav() {
      navbar.classList.toggle('active');
  }

  // Seleccionamos los elementos necesarios del DOM
  const burgerMenu = document.querySelector('.icono-menu-lateral');
  const navbar = document.querySelector('.opciones-header');
  const closeButton = document.querySelector('.close'); // Seleccionamos el botón de cierre

  // Añadimos eventos de clic a los elementos seleccionados
  burgerMenu.addEventListener('click', toggleNav);
  closeButton.addEventListener('click', toggleNav); // Añadimos el evento al botón de cierre
});


// funcion logout para página de inicio de sesión

function navigate() {
  window.location.href = "http://127.0.0.1:5500/login/loginyregistro.html";
}
// Seleccionamos el enlace de cierre de sesión en el documento HTML .logout-link

const logoutLink = document.querySelector(".logout-link");

// Agregamos un event listener al enlace de cierre de sesión

  logoutLink.addEventListener("click", function (event) {
    event.preventDefault();
     
    // Eliminamos los datos de usuario y token del almacenamiento local del navegador

    localStorage.removeItem("user");
    localStorage.removeItem("token");
   
   // volver a la página de inicio de sesión
    navigate();
  });





//////////////////////////FINAL DE LA FUNCTION/////////////////////////////////////////
////////////////////////////////silder

document.addEventListener('DOMContentLoaded', function() {
   // Remueve la clase 'hidden' del overlay cuando el contenido está cargado
  OVERLAY.classList.remove('hidden')
let slider_index = 0
const SLIDES = document.querySelectorAll('.slider-img')
const TOTAL_SLIDES = SLIDES.length
const NEXT_BUTTON = document.querySelector('.slider-btn--right')
const PREV_BUTTON = document.querySelector('.slider-btn--left')
const SLIDE_INTERVAL = 2500

/* ------------------------------------------------------------------------------------------------------- */

function setupSlides() {
  SLIDES.forEach((slide, index) => {
    slide.style.transition = 'transform 0.5s ease-in-out'
    slide.style.transform = `translateX(-${index * 100}%)`
  })
}

function showSlide(index) {
  const OFFSET = index * 100
  SLIDES.forEach((slide) => {
    slide.style.transform = `translateX(-${OFFSET}%)`
  })
}

function nextSlide() {
  slider_index = (slider_index + 1) % TOTAL_SLIDES
  showSlide(slider_index)
}

function prevSlide() {
  slider_index = (slider_index - 1 + TOTAL_SLIDES) % TOTAL_SLIDES
  showSlide(slider_index)
}

function autoChangeSlides() {
  nextSlide()
  setTimeout(autoChangeSlides, SLIDE_INTERVAL)
}

/* ------------------------------------------------------------------------------------------------------- */
 // Event listeners para los botones de navegación
NEXT_BUTTON.addEventListener('click', nextSlide)
PREV_BUTTON.addEventListener('click', prevSlide)

// Event listener para la navegación con teclado (flechas izquierda/derecha)
document.addEventListener('keydown', function(event) {
  if (document.activeElement === document.body) {
    return
  }
  if (document.activeElement !== NEXT_BUTTON && document.activeElement !== PREV_BUTTON) {
    return
  }

  if (event.key === 'ArrowRight') {
    nextSlide()
  } else if (event.key === 'ArrowLeft') {
    prevSlide()
  }
})

setupSlides()
showSlide(slider_index)
autoChangeSlides()



/*********************FINAL  FUNCTION DE SLIDER************************************ */



/////////////////Formulario PEDIR PRESUPUESTO///////////////////

document.getElementById("cta-form").addEventListener("submit", function(event) {
 
  //Evita que el formulario se envíe de la manera predeterminada
  event.preventDefault(); 
  
  // Obtiene los valores de los campos del formulario
  let name = document.getElementById("cta_name").value;
  let email = document.getElementById("cta_email").value;
  let tel = document.getElementById("cta_telefono").value;
  let categoria = document.getElementById("cta-subscription").value;
  let mensaje = document.getElementById("cta-mensaje").value;
    
  // Crea un objeto FormData y agrega los valores del formulario a él
  let formData = new FormData();
  formData.append("name", name);
  formData.append("email", email);
  formData.append("tel", tel);
  formData.append("categoria", categoria);
  formData.append("mensaje", mensaje);

 
  // Realiza una solicitud fetch para enviar los datos del formulario 
  //MANEJANDO EL METODO POST Y la respuesta json 
  // Imprimimos los datos devueltos en la consola

  fetch("http://localhost/api/sendEmail", {
    method: "POST",
    body: formData
})
.then((response) => {
    if (!response.ok) {
        throw new Error('Network response was not ok');
    }
    return response.json(); 
})
.then((data) => {
    console.log(data);
    alert(data.message);
})
.catch((error) => {
  
    alert("Error al enviar el mensaje: " + error.message);
    console.error("Error:", error);
});
  // Reinicia el formulario después de enviarlo
  document.getElementById("cta-form").reset();
});



/***************************ACCORDION************************** */


   // Seleccionamos todos los elementos  "accordion-item-header"
const accordionItemHeaders = document.querySelectorAll(".accordion-item-header");

// Itera sobre cada uno elemento selecionado
accordionItemHeaders.forEach(accordionItemHeader => {
    // hacer un evento "click" a cada elemento
    accordionItemHeader.addEventListener("click", event => {

      accordionItemHeader.classList.toggle("active");

        // Obtiene el siguiente elemento  manejando nextSibiling
        const accordionItemBody = accordionItemHeader.nextElementSibling;

        //hacemos la logica si esta activo o no
        if (accordionItemHeader.classList.contains("active")) {
            accordionItemBody.style.maxHeight = accordionItemBody.scrollHeight + "px";
        } else {
            accordionItemBody.style.maxHeight = 0;
        }
    });
});





/************************SCROLL TOP CON INTERVAL******** */

document.addEventListener("scroll", scrollFunction);
document.getElementById("scrollToTopBtn").addEventListener("click", scrollToTop);

function scrollFunction() {
  var button = document.getElementById("scrollToTopBtn");
  if (document.body.scrollTop > 20 || document.documentElement.scrollTop > 20) {
    button.style.display = "block";
  } else {
    button.style.display = "none";
  }
}

function scrollToTop() {
  // Obtenemos la posición actual de desplazamiento
  var currentScroll = document.documentElement.scrollTop || document.body.scrollTop;
  if (currentScroll > 0) {
    // Creamos una animación de desplazamiento hacia arriba
    var scrollStep = -currentScroll / 45;
    var scrollInterval = setInterval(function() {
      if (document.body.scrollTop === 0 && document.documentElement.scrollTop === 0) {
        clearInterval(scrollInterval); // Detenemos la animación cuando llegamos al principio
      } else {
        window.scrollBy(0, scrollStep); // Desplazamos la ventana hacia arriba
      }
    },45 ); 
  }
}



})









