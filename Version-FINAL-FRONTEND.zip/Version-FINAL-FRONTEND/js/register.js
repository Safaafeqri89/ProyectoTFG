// el formulario de registro register.js se encarga de validar los datos de un formulario de 
//registro y enviar estos datos y validation  la contraseña se coinceden se
//registra sino devuelve un mensaje


document.getElementById('submitRegístrate').addEventListener('click',function(event){

    //Evita que el formulario se envíe de manera predeterminada al hacer clic en el botón de envío.
    event.preventDefault(); 
   
    // Obtener los valores de los campos del formulario
    const nombreCompleto = document.getElementById('nombre_completo').value;
    const correoElectronico = document.getElementById('correo_electronico').value;
    const contraseña = document.getElementById('contraseña').value;
    const contraseñaConfirmation = document.getElementById('contraseña_confirmation').value;
    const errorPassword = document.getElementById('errorPassword');
    const valid = /^(?=.*\d).{8,}$/;

    //Validar la contraseña
    if (!valid.test(contraseña)) {
        errorPassword.innerHTML = "La contraseña debe tener al menos 8 caracteres y 1 número.";
    } else if (contraseña !== contraseñaConfirmation) {
        errorPassword.innerHTML = "Error: las contraseñas no coinciden.";
    } else {
        errorPassword.innerHTML = "";
        
        //Crear un objeto formData y enviar una solicitud POST si las validaciones pasan
        const formData = {
            nombre_completo: nombreCompleto,
            correo_electronico: correoElectronico,
            contraseña: contraseña,
            contraseña_confirmation: contraseñaConfirmation
        };
   // Se utiliza fetch para enviar una solicitud HTTP POST al servidor con los datos del formulario en formato JSON
    
        fetch('http://localhost/api/register', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Accept': 'application/json',
            },
            body: JSON.stringify(formData)
        })
        .then(response => response.json()
    )
        .then(data => {
    
    
            if (data.errors) {
                console.error(data.errors);
            } else {
    
                console.log(data.message);
                location.reload()
            }
        })
        .catch(error => {
            console.error('Error:', error);
        });
    }
})


