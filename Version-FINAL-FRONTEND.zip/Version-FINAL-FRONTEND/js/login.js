
/**************Buton CLOSE MENU HAMBURGESA************* */
// Función para alternar la clase 'active' en el navbar al hacer clic en el icono del menú lateral o en el botón de cierre.

function toggleNav(){
  navbar.classList.toggle('active');
}
// Selección de elementos del DOM
const burgerMenu = document.querySelector('.icono-menu-lateral');
const navbar = document.querySelector('.opciones-header'); 
const closeButton = document.querySelector('.close');
// Event Listeners para abrir y cerrar el navbar al hacer clic en el icono del menú o en el botón de cierre.

burgerMenu.addEventListener('click',toggleNav);
closeButton.addEventListener('click',toggleNav)

/**  declarar Variables formulario login */

const botonRegistro = document.getElementById("boton_registro");
const botonInicioSesion = document.getElementById("boton_inicio_sesion");
const formulariosUsuario = document.getElementById("formularios_opciones-usuario");

// Event Listeners para cambiar entre formularios de registro e inicio de sesión

botonRegistro.addEventListener("click", () => {
  formulariosUsuario.classList.remove("Right");
  formulariosUsuario.classList.add("Left");
});


botonInicioSesion.addEventListener("click", () => {
  formulariosUsuario.classList.remove("Left");
  formulariosUsuario.classList.add("Right");
});

function navigarMember() {
  window.location.href = "http://127.0.0.1:5500/categorias/servicios.html";
}

function navigarAdmin() {
  window.location.href = "http://127.0.0.1:5500/admin/dashboard.html";
}
// Función asincrónica para manejar el inicio de sesión del usuario

async function loginUser(event) {
  event.preventDefault();
  const email = document.getElementById("correo_electronico1").value;
  const password = document.getElementById("contraseña1").value;
  const emailError = document.getElementById("correoError");
  const passwordError = document.getElementById("contraseñaError");

  try {
    const formData = { email, password };
    const response = await fetch("http://localhost/api/login", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Accept: "application/json",
      },
      body: JSON.stringify(formData),
    });

    if (!response.ok) {
      throw new Error("Error en la solicitud");
    }

    const data = await response.json();

    if (data.status) {
      console.log(data);
      localStorage.setItem("user", JSON.stringify(data.user));
     localStorage.setItem("token",data.access_token);
      if (data.user.role === "admin") {
        navigarAdmin();
      } else if (data.user.role === "member") {
        navigarMember();
      }
    } else {
      
    }
  } catch (error) {
    console.error("Error:", error);
    emailError.textContent = "Correo o Contraseña incorrecta";
  }
}

document.getElementById("submitLogin").addEventListener("click", loginUser);

// Obtener usuario desde el almacenamiento local (localStorage)
const user = JSON.parse(localStorage.getItem("user"));
// Redireccionar según el rol del usuario almacenado en localStorage

 if (user.role == "member") {
  navigarMember();
 } else if (user.role == "admin" ){
  navigarAdmin();
 }else{
    // Si no hay usuario o el rol es desconocido, redirigir a la página de inicio de sesión

  window.location.href= "http://127.0.0.1:5500/login/loginyregistro.html";
 }

